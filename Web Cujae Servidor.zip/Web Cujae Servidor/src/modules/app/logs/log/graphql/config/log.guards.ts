import { GuardsDefinition } from '@regiondev/nestjs-common'

export const logGuards: GuardsDefinition = {}
