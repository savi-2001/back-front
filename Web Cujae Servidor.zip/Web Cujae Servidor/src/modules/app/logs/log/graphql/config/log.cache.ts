import { CacheQuerys } from '@regiondev/nestjs-common'

export const logCache: CacheQuerys = {
	policy: 'NONE', // disable cache for all querys
}
