export interface ValidateUserPayload {
	sub: string
}
