import { GuardsDefinition } from '@regiondev/nestjs-common'

export const eventGuards: GuardsDefinition = {}
