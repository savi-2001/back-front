import { CacheQuerys } from '@regiondev/nestjs-common'

export const page_viewCache: CacheQuerys = {
	policy: 'NONE', // disable cache for all querys
}
