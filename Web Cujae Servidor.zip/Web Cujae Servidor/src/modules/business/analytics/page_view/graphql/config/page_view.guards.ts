import { GuardsDefinition } from '@regiondev/nestjs-common'

export const page_viewGuards: GuardsDefinition = {}
