import { GuardsDefinition } from '@regiondev/nestjs-common'

export const articleGuards: GuardsDefinition = {
	
}
