export const MONGO_OPTIONS = {
	useNewUrlParser: true,
	useUnifiedTopology: true,
}
